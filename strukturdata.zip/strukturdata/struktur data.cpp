
// Nama : Alivi Milova 123170062

#include <iostream>
#include <iomanip>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#define True 1
#define False 0

using namespace std;

//BAGIAN QUEUE untuk menu CS
typedef char typeinfo;
typedef struct typequeue *typeptr;

struct data { char nama[30], id[10];
  			 int umur;
			};
			
struct simpan { char nama[30], id[10];
				int umur;
			  };
			  
struct typequeue{	typeptr next;
					data info;
					simpan info2;
				};
				
typeptr qdepan, qbelakang, qdepan1,qbelakang1;
void buatqueue();
int queuekosong();
void enqueue(char nama2[], char id2[], int umur2);
void dequeue();
void cetakqueue();
void cetakqueuearsip();
void batal();
int noo=0,noarsip=0;

void cs();
void teller();

//BAGIAN LINKED LIST untuk menu teller
typedef struct node *typepointer;
struct data_invent
{
	char nama[50], kode[10], jenis[20];
	int jumlah;
};
struct node
{

	data_invent info;
	typepointer next;
};

typepointer awal, akhir;
void buatlistbaru();
void sisipnode(char barang[50], char kodebr[10], char jenisbr[50], int jumlahbr);
void hapusnode(char hapuskan[50]);
void tampil();
void carinode(char caridata[50]);

int listkosong();

//MENU UTAMA
int main()
{ 	string user,pass;
	int menu;
	char jawab;
	cout<<"_____________________________________________________________";
	cout<<endl;
	cout<<"Username = "; cin>>user;
	cout<<"\nPassword = "; cin>>pass;
	if(user=="alivi"&&pass=="123")
	{
		do{
			system("cls");
	cout<<"\n===== SELAMAT DATANG DI BANK IKAVI =====\n";
	cout<<"\n||\t[1] TELLER                       ||";
	cout<<"\n||\t[2] CS (CUSTOMER SERVICE)        ||";
	cout<<"\n||\t[0] CANCEL    		              ||";
	cout<<"\n==========================================\n";
	cout<<"\nMasukkan pilian anda [0..2] >> ";
	cin>>menu;
	cout<<"_____________________________________________________________";
	switch (menu){
		case 1 :
			teller();	//menggunakan linked list
		break;
		
		case 2 :
			cs();	// menggunakan queue
			
		break;
		
		case 0 :
		exit(0);
		break;
		
		default :
			cout<<"\nPilihan anda tidak ada !";
		
	}cout<<"\nIngin Kembali ke menu utama? [Y/N] >> ";cin>>jawab;
		system("cls");
		}while(jawab=='Y'||jawab=='y');
	}
	else
	cout<<"\nLogin Gagal !";

}

void teller(){
	char nasabah[50], kodebr[10], jenisbr[50], hapuskan[50], caridata[50];
	int menu,pilih;
	char menuteller,kd;
	long int jumlahbr, jum;
	system("cls");
	do{
			cout<<"====== MENU TELLER ======\n\n"<<endl;
	cout<<"[1] Input Transaksi\n";
	cout<<"[2] Tampil Data Transaksi\n";
	cout<<"[3] Cari Data Transaksi\n";
	cout<<"[4] Proses Transaksi\n";
	cout<<"[5] Ke menu utama\n";
	cout<<"[0] Exit\n";
	cout<<"Pilihan anda : ";cin>>menu;
	switch(menu)
	{
		case 1:
		{
			buatlistbaru();
			int n;
			
			cout<<"Jumlah Data Transaksi : ";cin>>n;	
			for (int i = 0; i < n; i++)
			{
				cin.ignore();
				cout<<"Data ke-"<<i+1<<endl;
				cout<<"Input Nama		: ";cin.getline(nasabah, 50);
				cout<<"Input Kode Transaksi	: ";cin.getline(kodebr, 10);
				cout<<"Input Jenis Transaksi	: ";cin.getline(jenisbr, 50);
				cout<<"Input Jumlah		: ";cin>>jumlahbr;
				sisipnode(nasabah,kodebr,jenisbr,jumlahbr);	
			}
		}break;
		
		case 2:
		{	system("cls");
			tampil();
			system("PAUSE");
		}break;
		
		case 3:
		{	system("cls");
			cout<<"\nCari data berdasarkan kode";
			cin.ignore();
			cout<<"\nmasukan kode transaksi yang ingin dicari : "; cin.getline(caridata, 50);
			carinode(caridata);
			getchar();
		
		}break;
		
		case 4:
		{	system("cls");
			cin.ignore();
			cout << "\nMemproses transaksi sesuai Kode: ";cin.getline(hapuskan, 50);
			hapusnode(hapuskan);
			getchar();
	
		}break;
		
		case 5 :
		{
			main();
		}
		case 0 :
			exit(0);
			break;
			
		default:
			cout<<"\nPilihan tidak ada !";
	}
		system("cls");
		cout<<"\nKembali ke menu Teller ? [y/n]> "; cin>>menuteller;
	}while(menuteller=='Y'||menuteller=='y');
}

//BAGIAN LINKED LIST untuk menu TELLER

void buatlistbaru()
{
	awal=NULL;//awal kosong
	akhir=NULL;//akhir kosong
}

int listkosong()
{
	
	if (awal==NULL) //cek nilai awal
	{
		return (true);
	}
	else 
	{
		return (false);
	}
}

void sisipnode(char nasabah[50], char kodebr[10], char jenisbr[50], int jumlahbr)
{
	typepointer NB, bantu;//variable bantu
	NB=(node *) malloc(sizeof(node));//NB sebagai Node kosong
	strcpy(NB->info.nama, nasabah);//barang menunjuk info.nama
	strcpy(NB->info.kode, kodebr);//kodebr menunjuk info.kode
	strcpy(NB->info.jenis, jenisbr);
	NB->info.jumlah=jumlahbr;//jumlahbr menunjuk info.jumlah
	NB->next=NULL;//next NB kosong
	if (listkosong())
	{
		awal=NB;
		akhir=NB;
	}
	else if (strcmp(kodebr, awal->info.kode)<0) //sisip depan
	{
		NB->next=awal;
		awal=NB;
	}
	else 
	{
		bantu=awal;
		while (bantu->next!=NULL && strcmp(kodebr, bantu->next->info.kode)>0)
		bantu=bantu->next;
		NB->next=bantu->next; //sisip tengah atau akhir
		bantu->next=NB;
		if (strcmp(kodebr, akhir->info.kode)>0)
		{
			akhir=NB;
		}
	}
}

void hapusnode(char hapuskan[50])
{
	typepointer hapus, bantu;
	if (listkosong())
	{
		cout << "\nTransaksi masih kosong ";
	}
	else if (strcmp(awal->info.kode, hapuskan)==0)   //hapus di awal
	{
		hapus=awal;
		awal= hapus->next;
		free(hapus);
		cout<<"\nTransaksi telah selesai dilakukan"<<endl;
	}
	else 
	{
		bantu=awal;
		while(bantu->next->next!=NULL && strcmp(hapuskan, bantu->next->info.kode)!=0)
		bantu=bantu->next;
		if (strcmp(hapuskan, bantu->next->info.kode)==0)
		{
			hapus=bantu->next;
			if(hapus==akhir)        //Hapus awal
			{
				akhir=bantu;
				akhir->next=NULL;
			}
			else
			{
				bantu->next=hapus->next;
				free(hapus);
			}
			
			cout<<"\nTransaksi telah selesai dilakukan"<<endl;
		}
		else 
		{
			cout << "Transaksi tidak ditemukan!\n";
		}
	}
}

void carinode(char caridata[50])
{
	typepointer cari, bantu;
	if (listkosong())
	{
		cout << "\nTransaksi masih kosong ";
	}
	else if (strcmp(awal->info.kode, caridata)==0)   //cari data di awal
	{
		cari=awal;
		awal= cari->next;
            cout<<"	Nama			: "<<cari->info.nama<<endl;
            cout<<"	Kode Transaksi		: "<<cari->info.kode<<endl;
            cout<<"	Jenis Transaksi		: "<<cari->info.jenis<<endl;
            cout<<"	Jumlah			: "<<cari->info.jumlah<<endl;
	}
	else 
	{
		bantu=awal;
		while(bantu->next->next!=NULL && strcmp(caridata, bantu->next->info.kode)!=0)
		bantu=bantu->next;
		if (strcmp(caridata, bantu->next->info.kode)==0)
		{
			cari=bantu->next;
			if(cari==akhir)        //cari data awal
			{
				akhir=bantu;
				akhir->next=NULL;
				 cout<<"	Nama			: "<<bantu->info.nama<<endl;
            cout<<"	Kode Transaksi		: "<<bantu->info.kode<<endl;
            cout<<"	Jenis Transaksi		: "<<bantu->info.jenis<<endl;
            cout<<"	Jumlah			: "<<bantu->info.jumlah<<endl;
			}
			else
			{
				bantu->next=cari->next;
				
			}
			
		}
		else 
		{
			cout << "Transaksi tidak ditemukan!\n";
		}
	}
}


void tampil()
{
	typepointer bantu;

	int a=0;
	bantu=awal;
	while (bantu!=NULL)
	{
			cout<<"Transaksi ke-"<<a+1<<" :\n";
            cout<<"	Nama			: "<<bantu->info.nama<<endl;
            cout<<"	Kode Transaksi		: "<<bantu->info.kode<<endl;
            cout<<"	Jenis Transaksi		: "<<bantu->info.jenis<<endl;
            cout<<"	Jumlah			: "<<bantu->info.jumlah<<endl;
            
		bantu=bantu->next;
		a++;
	}
}


void cs(){
	char pilih;
	char nama2[30],id2[10];
	int angka, umur2;
	
	do{ angka=1;
		system("cls");
		if(!queuekosong())
			cetakqueue();
		cout<<"\n======= ANTRIAN CS BANK =======";
		cout<<"\n [1] Pendaftaran";
		cout<<"\n [2] Lihat Daftar Antrian";
		cout<<"\n [3] Memproses antrian";
		cout<<"\n [4] Daftar Antrian Yang Sudah di Proses";
		cout<<"\n [5] Batalkan antrian terakhir";
		cout<<"\n [6] Ke menu utama";
		cout<<"\n [0] Exit";
		cout<<"\n\nMasukkan pilihan anda >> [0...5] "; 
		cin>>pilih;		
			system("cls");
			switch(pilih){
				case '1' :	
					cout<<"\n________________________________________";
					cout<<"\n\tPendaftaran nasabah";
					cout<<"\n________________________________________";
							if(queuekosong())
							{
								buatqueue();
							}
							while(angka==1)
							{
								if(!queuekosong())
								{
								cetakqueue();
								}
								noo++;
								cout<<"\n\tID Nasabah	: ";
								cin>>id2;
								cout<<"\n\tNama		: ";
								cin.ignore();cin.getline(nama2,sizeof(nama2));
								cout<<"\n\tUmur		: ";
								cin>>umur2;
								enqueue(nama2,id2,umur2);
								cout<<"\n\t(Input data lagi tekan 1, dan Selesai tekan 0 )";
								cout<<"\n\tinput lagi ? =  ";
								cin>>angka;
								system("cls");
							}
								break;
				case '2' : if(!queuekosong())
							{
							cetakqueue();
							}
							else
							cout<<"\nANTRIAN KOSONG!!!";
							break;
				case '3' :	if(!queuekosong())
							{
								dequeue();
								cout<<"\n_____________________________________";
								cout<<"\nsatu data sudah berhasil diproses !";
								cout<<"\n_____________________________________";
							}
							else
								cout<<"\nAntrian Kosong"<<endl;
							break;
				case '4' :
					cout<<"\n__________________________________________";
					cout<<"\nDaftar antrian yang sudah diproses !";
					cout<<"\n__________________________________________"; 
							if(noarsip!=0)
							cetakqueuearsip();
							else
							cout<<"\nBelum ada antrian yang diproses!"<<endl;
							break;
				case '5' : if(!queuekosong()) 
							{
								batal();
								cout<<"\n_____________________________________";
								cout<<"\nAntrian terakhir berhasil dibatalkan !";
								cout<<"\n_____________________________________";
							}
							else
								cout<<"\nBelum ada antrian yang didaftarkan !"<<endl;
							break;
				case '6' :
				main();
				break; 
				case '0' : exit(0);
							break;
				default : cout<<"\nMenu tidak ada di pilihan"<<endl;
							break;
			}cout<<"\nIngin Kembali ke menu ? [Y/N] >> ";cin>>pilih;
			system("cls");
		}while(pilih=='Y'||pilih=='y');
}

// BAGIAN QUEUE

void buatqueue()
{ qdepan=(typequeue *) malloc(sizeof(typequeue));
  qdepan=NULL;
  qbelakang=qdepan;
  //arsip atau simpan data yang sudah di dadftarkan
  qdepan1=(typequeue *) malloc(sizeof(typequeue));
  qdepan1=NULL;
  qbelakang1=qdepan;
  
}
int queuekosong()
{ if(qdepan==NULL)
	 return(True);
  else
	 return(False);
}
void enqueue(char nama2[], char id2[], int umur2)
{ typeptr NB;
  NB=(typequeue *) malloc(sizeof(typequeue));
  strcpy(NB->info.id,id2);
  strcpy(NB->info.nama,nama2);
  NB->info.umur=umur2;
  if (qdepan==NULL)
	  qdepan=NB;
  else
	  qbelakang->next=NB;
  qbelakang=NB;
  qbelakang->next=NULL;
}
void dequeue()
{
  typeptr hapus;
  if (queuekosong())
  { 
     cout << "\nQueue masih kosong !";
  }
  else
  {  hapus=qdepan;
	 qdepan=hapus->next;
	 
	 {
	 typeptr NB;
	  NB=(typequeue *) malloc(sizeof(typequeue));
	  strcpy(NB->info2.id,hapus->info.id);
	  strcpy(NB->info2.nama,hapus->info.nama);
	  NB->info2.umur=hapus->info.umur;
	  if (qdepan1==NULL)
	  	qdepan1=NB;
	  else
		  qbelakang1->next=NB;
	  qbelakang1=NB;
	  qbelakang1->next=NULL;
	  noarsip++;
	 }//arsip
	 
	 free(hapus); noo--;
	 cout<<"\n"<<qbelakang1->info2.nama<<endl;
	 }
}

void cetakqueue()
{	typeptr bantu;
	int i=0;
 	bantu=qdepan;
	cout<<"\n\t======== DAFTAR ANTRIAN ========"<<endl;
	cout<<setw(4)<<"No"<<setw(15)<<"ID Nasabah"<<setw(25)<<"Nama"<<setw(15)<<"Umur"<<endl;
  	do {i++;
	  cout<<setw(4)<<i<<setw(15)<<bantu->info.id<<setw(25)<<bantu->info.nama<<setw(15)<<bantu->info.umur<<endl;
		 bantu=bantu->next;
		 
  	} while(bantu!=NULL && i!=noo);
  	cout<<"\nJUMLAH ANTRIAN : "<<noo;
  	
}
void cetakqueuearsip()
{	typeptr bantu;
	int i=0;
 	bantu=qdepan1;
	cout<<"\n\t===== DAFTAR ANTRIAN YANG TELAH DIPROSES ====="<<endl;
	cout<<setw(4)<<"No"<<setw(15)<<"ID Nasabah"<<setw(25)<<"Nama"<<setw(15)<<"Umur"<<endl;
  	do {i++;
	  cout<<setw(4)<<i<<setw(15)<<bantu->info2.id<<setw(25)<<bantu->info2.nama<<setw(15)<<bantu->info2.umur<<endl;
		 bantu=bantu->next;
		 
  	} while(bantu!=NULL && i!=noarsip);
  	cout<<endl;
  	cout<<"\nJumlah antrian = "<<noo;
}
void batal()
{
  typeptr hapus;
  if (queuekosong())
  { 
     cout << "\nQueue masih kosong !";
  }
  else
  {  hapus=qbelakang;
	 qbelakang=hapus->next;
	 
	 {
	 typeptr NB;
	  NB=(typequeue *) malloc(sizeof(typequeue));
	  strcpy(NB->info2.id,hapus->info.id);
	  strcpy(NB->info2.nama,hapus->info.nama);
	  NB->info2.umur= hapus->info.umur;
	  if (qbelakang1==NULL)
	  	qbelakang1=NB;
	  else
		  qdepan1->next=NB;
	  qdepan1=NB;
	  qdepan1->next=NULL;
	  free(hapus); noo--;
	 cout<<"\n"<<qdepan1->info2.nama<<endl;
	 }
	 
	 }
}
//QUEUE SELESAI
//----------------------------------------------------------------

//terimakasih atas bantuan dari berbagai pihak
//tunggu program selanjutnya gaesss :)



